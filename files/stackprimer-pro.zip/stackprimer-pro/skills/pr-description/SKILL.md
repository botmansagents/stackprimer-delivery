---
name: pr-description
description: Write a clear pull request description
---
# pr-description

Write a clear pull request description.

## Steps
1. Read the full diff and linked issue.
2. Title: imperative, under ~70 characters.
3. Body sections: Why (problem), What (key changes), How to test (exact steps/commands), Risk and rollback, Screenshots if UI.
4. Call out migrations, config/env changes, and breaking changes explicitly.
5. Don't claim tests pass unless you ran them; paste the command you ran.
6. Keep it short; link to code instead of repeating it.
