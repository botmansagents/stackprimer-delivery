---
name: code-review
description: Review a diff for bugs, security and clarity
---
# code-review

Review a diff for bugs, security and clarity.

## Steps
1. Read the diff and the surrounding code; understand intent from the PR/issue.
2. Check correctness first: logic, edge cases, error handling, concurrency.
3. Security: input validation, authz checks, injection, secrets, unsafe deserialization.
4. Tests: does the change have tests that would catch a regression?
5. Then readability and naming. Skip style nits a linter would catch.
6. Output findings by severity (blocker / should-fix / nit) with file:line and a suggested fix.
