---
name: debug-failure
description: Find the root cause of a failing test, error or bug
---
# debug-failure

Find the root cause of a failing test, error or bug.

## Steps
1. Reproduce: get the exact command and full error output.
2. Read the stack trace from the first frame in project code.
3. Form one hypothesis at a time; test it with a log, a breakpoint, or a minimal repro.
4. Check recent changes (`git log -p`, `git bisect`) if it used to work.
5. Fix the root cause, not the symptom; don't loosen assertions or skip tests.
6. Add a regression test, re-run the full suite, and explain the cause in one paragraph.
