---
name: safe-refactor
description: Restructure code without changing behavior
---
# safe-refactor

Restructure code without changing behavior.

## Steps
1. Confirm tests cover the code to be changed; add characterization tests if not.
2. Make one mechanical step at a time (rename, extract, move, inline).
3. Run tests after each step; commit or checkpoint when green.
4. Don't mix behavior changes into a refactor; note them separately.
5. Update imports, docs and call sites; search for string/reflective references.
6. Finish with lint, type check and full test run; summarize what moved where.
