---
name: write-tests
description: Write tests for new or changed code
---
# write-tests

Write tests for new or changed code.

## Steps
1. Find the project's test framework and an existing test near the code; copy its style.
2. List behaviors: happy path, edge cases (empty, max, invalid), error paths.
3. Write the smallest tests that pin each behavior; no testing private internals.
4. Mock only external boundaries (network, clock, randomness).
5. Run the test command; confirm new tests fail without the change if feasible, and pass with it.
6. Report what is covered and what isn't.
