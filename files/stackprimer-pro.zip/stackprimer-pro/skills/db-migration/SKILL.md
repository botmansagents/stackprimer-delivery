---
name: db-migration
description: Write and ship a database schema change safely
---
# db-migration

Write and ship a database schema change safely.

## Steps
1. Use the project's migration tool; never hand-edit the production schema.
2. Prefer additive, backward-compatible steps (expand, migrate data, contract) so old and new code both run during deploy.
3. Add indexes concurrently/online where the database supports it; avoid long table locks.
4. Make the migration reversible or document why not.
5. Backfill in batches; don't load whole tables into memory.
6. Test up and down locally against a copy of realistic data; list the deploy order in the PR.
