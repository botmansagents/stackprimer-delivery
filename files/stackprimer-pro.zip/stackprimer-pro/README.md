# StackPrimer Pro v1.0.0

Ready-to-paste instruction files for AI coding agents. Each stack has a scoped Cursor rule (`.mdc`), `CLAUDE.md` and `AGENTS.md` covering current idioms, security basics and the lint/test commands to run before the agent says it's done.

## Stacks
- `nextjs-app-router`: Next.js (App Router)
- `python-fastapi`: Python / FastAPI
- `django`: Django
- `rails`: Ruby on Rails
- `go`: Go
- `rust`: Rust
- `react-native-expo`: React Native (Expo)
- `node-express`: Node.js / Express
- `laravel`: Laravel
- `data-science`: Data science (Python, pandas, notebooks)

## Pro extras
- `skills/`: 6 agent skills (SKILL.md): write-tests, code-review, debug-failure, safe-refactor, db-migration, pr-description. Copy a folder into `.claude/skills/` (Claude Code) or `.cursor/skills/`, or paste the steps into your agent's instructions.
- `mcp/`: sample MCP configs for Cursor and Claude Code (GitHub, Playwright, Filesystem, Context7) with setup notes.

## How to install a stack
1. Copy `stacks/<stack>/.cursor/rules/<stack>.mdc` into your repo's `.cursor/rules/`.
2. Copy `CLAUDE.md` and/or `AGENTS.md` to your repo root (or merge into existing ones).
3. Edit the "Before you say you're done" commands to match your package scripts.

These are starting points written for general projects. Read them, trim what doesn't fit, and adjust commands. See LICENSE.txt for terms (use in your projects OK, no resale, 30-day refund on paid tiers).
