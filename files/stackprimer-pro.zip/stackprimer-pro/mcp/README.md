# MCP config samples (Cursor and Claude Code)

These are sample configs for four widely used MCP servers. Package names and
options change; check each server's own README before relying on them.

| Server | Purpose | Notes |
| --- | --- | --- |
| GitHub | Issues, PRs, repo files | Official `ghcr.io/github/github-mcp-server` via Docker. Needs Docker + a fine-grained personal access token with only the repos/permissions you need. Remote option: `https://api.githubcopilot.com/mcp/` (see GitHub docs). Do not use deprecated `@modelcontextprotocol/server-github`. |
| Playwright | Drive a browser for UI checks | `@playwright/mcp`. First run may need `npx playwright install`. |
| Filesystem | Read/write files in allowed dirs | Replace `/path/to/your/project`; only list directories you want the agent to touch. |
| Context7 | Up-to-date library docs | `@upstash/context7-mcp`. An API key is optional for higher limits. |

## Cursor
Copy `cursor/mcp.json` to `.cursor/mcp.json` (project) or `~/.cursor/mcp.json` (global). Restart Cursor, then check Settings > MCP.

## Claude Code
Copy `claude-code/.mcp.json` to your project root (project scope), or add servers with
`claude mcp add <name> -- <command> <args...>`. Run `claude mcp list` to verify.

## Security
- Never commit real tokens. The configs reference env vars; export them in your shell or a secret manager.
- Only enable servers you need; each one gives the agent new powers.
- Requires Docker for the GitHub sample, and Node.js 20+ recommended for `npx` servers (Context7 documents Node >= 20.18; Playwright accepts 18+).
