# CLAUDE.md: Go project

Instructions for Claude Code in this repo. Edit the commands to match your scripts.

## Rules
- Match the `go` version in go.mod. On Go 1.22+, use `net/http` method and wildcard patterns (`mux.HandleFunc("GET /items/{id}", h)`, `r.PathValue("id")`) before adding a router dependency.
- Return errors, don't panic. Wrap with `fmt.Errorf("doing x: %w", err)` and check with `errors.Is/As`.
- Pass `context.Context` as the first parameter for I/O; respect cancellation; set timeouts on `http.Server` and clients.
- Use `log/slog` for structured logging. Never log secrets or tokens.
- Use `database/sql` placeholders; never fmt SQL strings.
- Avoid global mutable state; guard shared data with channels or `sync` primitives and run tests with `-race`.
- Keep packages small; accept interfaces, return structs; no `utils` dumping ground.
- Table-driven tests with `t.Run`; `httptest` for handlers.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `gofmt -l .`
- `go vet ./...`
- `staticcheck ./...` (if installed)
- `go test -race ./...`

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
