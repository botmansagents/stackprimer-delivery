# AGENTS.md: Next.js (App Router) project

Instructions for coding agents (Codex, Cursor, others that read AGENTS.md).

## Rules
- Use the App Router (`app/`). Components are Server Components by default; add `"use client"` only for state, effects, or browser APIs, and keep client components at the leaves.
- In Next.js 15+, `params` and `searchParams` are Promises in pages, layouts and route handlers: `const { id } = await params`. `cookies()` and `headers()` are async too.
- Fetch data in Server Components or Server Actions, not in `useEffect`. Be explicit about caching (`cache: 'no-store'`, `revalidate`, `revalidateTag`); fetch is not cached by default in 15+.
- Mutations go through Server Actions or route handlers (`app/api/**/route.ts`). Validate every input with a schema (e.g. Zod) on the server; never trust form data.
- Secrets stay server-side. Only `NEXT_PUBLIC_*` variables reach the browser; never put keys in them. Import `server-only` in modules that must not be bundled to the client.
- Check auth and authorization inside each Server Action and route handler, not only in middleware.
- Use `next/image`, `next/link` and `next/font`; use `loading.tsx`, `error.tsx` and `not-found.tsx` instead of hand-rolled states.
- TypeScript strict mode; no `any` without a comment explaining why.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `npm run lint`
- `npx tsc --noEmit`
- `npm test`
- `npm run build`

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
