# AGENTS.md: Data science (Python, pandas, notebooks) project

Instructions for coding agents (Codex, Cursor, others that read AGENTS.md).

## Rules
- Keep reusable logic in `.py` modules; notebooks call them. Notebooks should run top-to-bottom cleanly.
- Set random seeds and record package versions (lock file or `requirements.txt`) for reproducibility.
- pandas: avoid chained assignment (use `.loc`); prefer vectorized ops over `apply`/loops; be explicit with dtypes and date parsing.
- Never commit raw data, credentials, or outputs with personal data; read paths and keys from config/env.
- Split train/validation/test before any fitting or scaling to avoid leakage; use pipelines (e.g. scikit-learn `Pipeline`).
- Report metrics with the baseline next to them; say what data and split produced them.
- Large files: stream or chunk; don't load more than you need.
- Add small tests for data-cleaning functions with tiny fixture frames.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `ruff check .`
- `pytest -q`
- `nbqa ruff .` (if notebooks)
- `jupyter nbconvert --execute --to notebook --inplace <nb>` (smoke-run)

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
