# AGENTS.md: Rust project

Instructions for coding agents (Codex, Cursor, others that read AGENTS.md).

## Rules
- Use the crate's edition from Cargo.toml (2021/2024 idioms).
- No `unwrap()`/`expect()` in library or request paths; propagate with `?`. Use `thiserror` for library errors and `anyhow` for binaries if the project already does.
- Prefer borrowing over cloning; don't add `.clone()` just to satisfy the borrow checker without saying why.
- `unsafe` only with a `// SAFETY:` comment explaining the invariant.
- Async: don't block inside async tasks (use `spawn_blocking`); don't hold a `std::sync::Mutex` guard across `.await`.
- Use `sqlx`/ORM bound parameters; never format SQL.
- Keep public APIs documented with `///` and examples that compile as doctests.
- New behavior needs unit tests (`#[cfg(test)]`) or integration tests in `tests/`.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `cargo fmt --check`
- `cargo clippy --all-targets -- -D warnings`
- `cargo test`

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
