# CLAUDE.md: React Native (Expo) project

Instructions for Claude Code in this repo. Edit the commands to match your scripts.

## Rules
- Use Expo SDK APIs (`expo-*` packages) and install with `npx expo install` so versions match the SDK.
- Use Expo Router (file-based routes in `app/`) if the project uses it; typed routes over string paths.
- Never store tokens in AsyncStorage; use `expo-secure-store`. No secrets in `app.json` or `EXPO_PUBLIC_*` vars (they ship in the bundle).
- Use `FlatList`/`FlashList` for long lists, never `ScrollView` + `map` for unbounded data.
- Respect safe areas (`react-native-safe-area-context`) and test both iOS and Android behavior.
- Function components and hooks only; keep server state in a query library (e.g. TanStack Query) if present.
- Ask for permissions at the moment of use and handle denial.
- TypeScript strict; no `any` without reason.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `npx expo lint`
- `npx tsc --noEmit`
- `npm test`
- `npx expo-doctor`

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
