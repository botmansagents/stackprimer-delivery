# AGENTS.md: Python / FastAPI project

Instructions for coding agents (Codex, Cursor, others that read AGENTS.md).

## Rules
- Use Pydantic v2: `model_config = ConfigDict(...)`, `model_validate`, `model_dump`, `field_validator`. Do not use v1 `class Config`, `.dict()` or `parse_obj`.
- Type every endpoint: request bodies as Pydantic models, `response_model` (or return annotations) so responses are filtered and documented.
- Use `Annotated[..., Depends(...)]` for dependencies (DB sessions, current user). Never create DB sessions at import time.
- `async def` endpoints must not call blocking I/O; use async drivers or plain `def` endpoints (run in a threadpool).
- Use `lifespan` context managers for startup/shutdown, not `@app.on_event`.
- Settings come from `pydantic-settings` `BaseSettings`; secrets from env, never hard-coded or logged.
- Hash passwords (argon2/bcrypt), use parameterized queries or the ORM, restrict CORS origins explicitly, and raise `HTTPException` with safe messages.
- Tests use `pytest` with `httpx.AsyncClient`/`TestClient` and dependency overrides, not a live database.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `ruff check .`
- `ruff format --check .`
- `mypy .`
- `pytest -q`

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
