# AGENTS.md: Node.js / Express project

Instructions for coding agents (Codex, Cursor, others that read AGENTS.md).

## Rules
- Use the project's module system (ESM vs CommonJS) consistently; target the Node LTS in `engines`/`.nvmrc`.
- Validate every request body, query and param with a schema (Zod/Joi/express-validator) before use.
- Async handlers must pass errors to `next(err)` (Express 5 does this for rejected promises; Express 4 needs a wrapper). One central error handler; no stack traces to clients in production.
- Use `helmet`, explicit CORS origins, and rate limiting on auth endpoints.
- Parameterized queries or the ORM only; never concatenate SQL or pass raw user objects to Mongo queries.
- Config from env (validated at startup); never commit `.env`.
- Hash passwords with argon2/bcrypt; set cookies `httpOnly`, `secure`, `sameSite`.
- Test routes with `supertest`; don't hit real third-party APIs in tests.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `npm run lint`
- `npx tsc --noEmit` (if TypeScript)
- `npm test`
- `npm audit --omit=dev`

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
