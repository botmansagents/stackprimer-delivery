# AGENTS.md: Laravel project

Instructions for coding agents (Codex, Cursor, others that read AGENTS.md).

## Rules
- Match the project's Laravel version (11+/12 slim skeleton: config in `bootstrap/app.php`, no `Kernel.php`).
- Validate with Form Requests; use `$request->validated()`, never `$request->all()` for mass assignment. Set `$fillable` on models.
- Authorize with Policies/Gates (`$this->authorize`, `can` middleware) on every non-public route.
- Eloquent or query builder bindings only; no raw string-built SQL. Eager load (`with`) to avoid N+1.
- Every schema change is a migration; never edit a migration already run in production.
- Blade escapes with `{{ }}`; use `{!! !!}` only for trusted, sanitized HTML.
- Secrets in `.env` via `config()`; never call `env()` outside config files.
- Queue slow work (mail, external APIs) with jobs; write Feature tests for new routes.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `./vendor/bin/pint --test`
- `php artisan test` (or ./vendor/bin/pest)
- `./vendor/bin/phpstan analyse` (if configured)

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
