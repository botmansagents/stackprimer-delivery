# CLAUDE.md: Django project

Instructions for Claude Code in this repo. Edit the commands to match your scripts.

## Rules
- Follow the project's Django version; prefer current APIs (`path()`, `models.TextChoices`, `constraints` over `unique_together`).
- Keep business logic out of views and templates: models/managers or a services module.
- Never build SQL with string formatting; use the ORM or `params=` in raw queries. Avoid N+1 with `select_related`/`prefetch_related`.
- Every model change needs a migration (`makemigrations`), reviewed before commit. Never edit applied migrations.
- Forms and DRF serializers validate all input. Keep CSRF on; don't use `csrf_exempt` without a written reason.
- Settings: `DEBUG=False` in production, `SECRET_KEY` and credentials from env, explicit `ALLOWED_HOSTS`.
- Use `@login_required`/permission classes on every non-public view; check object-level ownership.
- Tests use `pytest-django` or `TestCase` with factories, not fixtures from production data.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `ruff check .`
- `python manage.py check`
- `python manage.py makemigrations --check --dry-run`
- `pytest -q`

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
