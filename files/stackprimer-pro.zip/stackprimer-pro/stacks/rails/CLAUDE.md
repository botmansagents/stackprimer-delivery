# CLAUDE.md: Ruby on Rails project

Instructions for Claude Code in this repo. Edit the commands to match your scripts.

## Rules
- Follow Rails conventions over configuration; match the app's Rails version (7.x/8.x idioms: Hotwire/Turbo, `params.expect` on 8, otherwise `params.require(...).permit(...)`).
- Always use strong params; never pass `params` straight to `create`/`update`.
- Keep controllers thin; put logic in models, concerns, or POROs under `app/services` if the project uses them.
- Queries: use Active Record with bound values, never string interpolation in `where`. Use `includes` to avoid N+1.
- Migrations must be reversible; add indexes and foreign keys for new associations; never edit a migration that has run in production.
- Credentials via `Rails.application.credentials` or env; never commit `master.key`.
- Authorize every action (Pundit/CanCanCan or explicit checks); scope lookups to `current_user`.
- Write request/system specs for new endpoints.

## Security basics
- Never commit secrets; read them from env/secret stores.
- Validate all external input at the boundary.
- Don't disable auth, CSRF, TLS checks, or lint rules to make something pass.

## Before you say you're done
Run these and fix failures (skip any the repo doesn't use):
- `bundle exec rubocop`
- `bundle exec rspec` (or bin/rails test)
- `bin/brakeman -q`

If you change behavior, add or update a test. If a command can't run, say so instead of claiming success.
